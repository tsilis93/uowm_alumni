<?php  


echo '<p id = "footer_text"><img src="copyright.png" alt="copyright-symbol" height="12" width="12"> Developed by <font color="#0645AD"> Tsilimparis Vasilis </font> - Supervised by <a href="http://arch.icte.uowm.gr/" target="_blank">Minas Dasygenis</a><br><font color="#0645AD"><a href="http://www.uowm.gr" target="_blank">University of Western Macedonia</a></font></p>';  


?>


