<?php

include ("connectPDO.php");

if(isset($_POST['title']))
{
	$title = $_POST['title'];
}

//$id = 1;
$alumni_id = 1;

$stmt2 = $conn->prepare("INSERT INTO notifications (text, alumni_id) VALUES (?, ?)");
if($stmt2->execute(array($title,$alumni_id))) 
{
	echo "δούλεψε";
}
else
{
	echo "Δεν δούλεψε";
}

?>
