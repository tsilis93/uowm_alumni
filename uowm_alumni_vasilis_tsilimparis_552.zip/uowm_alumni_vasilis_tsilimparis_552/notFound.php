<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>UOWM Alumni</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
     <link rel="stylesheet" href="css/notFound.css">
	 
</head>
<body>	 
<?php
header("HTTP/1.0 404 Not Found");

echo '<div class="centered">';
echo	'<img src="assets/UOWM-logo.png" alt="UOWM-logo"  height = "60px">';
echo 	"<h1>404 Not Found</h1>";
echo 	"The page that you have requested could not be found.";
echo '</div>';

exit();

?>	


</body>
</html>